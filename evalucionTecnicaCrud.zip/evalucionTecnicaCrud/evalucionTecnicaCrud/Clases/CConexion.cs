﻿using Google.Protobuf;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace evalucionTecnicaCrud.Clases
{
    internal class CConexion
    {
        private MySqlConnection conex;

        private static string servidor = "localhost";
        private static string bd = "evaluacion";
        private static string usuario = "root";
        private static string password = "roor";
        private static string puerto = "3306";

        string cadenaConexion = "server=" + servidor + ";" + "port=" + puerto+";" + "user id=" + usuario + ";"  +"password=" + password + ";" + "database=" + bd + ";";

        public MySqlConnection establecerConexion()
        {
            try
            {
                conex = new MySqlConnection(cadenaConexion);
                conex.Open();
                // MessageBox.Show("Conexión exitosa a la BD");
            }
            catch (Exception ex)
            {
                MessageBox.Show("No conectó a la base de datos, error: " + ex.ToString());
            }
            return conex;
        }

        public void cerrarConexion()
        {
            if (conex != null && conex.State == System.Data.ConnectionState.Open)
            {
                conex.Close();
                MessageBox.Show("Conexión cerrada");
            }
        }
    }
 }
