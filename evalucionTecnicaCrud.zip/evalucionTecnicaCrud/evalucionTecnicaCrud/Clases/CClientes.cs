﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace evalucionTecnicaCrud.Clases
{
    internal class CClientes
    {
        public void mostrarClientes(DataGridView tablaClientes)
        {
            try
            {
                //CONEXION BD - AVALUACION

                CConexion objetoConexion = new CConexion();
                string query = "select * from clientes;";
                tablaClientes.DataSource = null;
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, objetoConexion.establecerConexion());
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                tablaClientes.DataSource = dt;
                //objetoConexion.cerrarConexion();
                
            }
            catch (Exception ex) {
                MessageBox.Show("No se pudo mostrar las informacion de la base de datos, error: " + ex.ToString());
            }
        }

        public void guardarClientes(TextBox nombres, TextBox identificaciones, TextBox correos, TextBox edades, TextBox
            celulares)
        {
            try
            {

                CConexion objetoConexion = new CConexion();
                string query = "insert into clientes (nombres, identificaciones, correos, edades, celulares)" + "values ('"+ nombres.Text+ "', '"+ identificaciones.Text+ "', '"+ correos.Text+ "', '"+ edades.Text+ "', '"+ celulares.Text+"');";
                MySqlCommand myComand = new MySqlCommand(query, objetoConexion.establecerConexion());
                MySqlDataReader reader = myComand.ExecuteReader();
                MessageBox.Show("Se guardo el registro");
                while (reader.Read())
                {

                }
                //objetoConexion.cerrarConexion();

            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo mostrar las informacion de la base de datos, error: " + ex.ToString());
            }
        }

        public void seleccionarClientes(DataGridView tablaClientes, TextBox id, TextBox nombres, TextBox identificaciones, TextBox correos, TextBox edades, TextBox
            celulares)
        {
            try
            {
                id.Text= tablaClientes.CurrentRow.Cells[0].Value.ToString();
                nombres.Text = tablaClientes.CurrentRow.Cells[1].Value.ToString();
                identificaciones.Text = tablaClientes.CurrentRow.Cells[2].Value.ToString();
                correos.Text = tablaClientes.CurrentRow.Cells[3].Value.ToString();
                edades.Text = tablaClientes.CurrentRow.Cells[4].Value.ToString();
                celulares.Text = tablaClientes.CurrentRow.Cells[5].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("No se logro seleccionar el dato, error: " + ex.ToString());
            }
        }

        public void modificarClientes(TextBox id, TextBox nombres, TextBox identificaciones, TextBox correos, TextBox edades, TextBox
            celulares)
        {
            try
            {

                CConexion objetoConexion = new CConexion();
                string query = "update  clientes set nombres='" + nombres.Text + "', identificaciones='" + identificaciones.Text + "', correos='" + correos.Text + "', edades='" + edades.Text + "', celulares='" + celulares.Text + "' where id = '" + id.Text + "';";
                MySqlCommand myComand = new MySqlCommand(query, objetoConexion.establecerConexion());
                MySqlDataReader reader = myComand.ExecuteReader();
                MessageBox.Show("Se modifico el registro");
                while (reader.Read())
                {

                }
                //objetoConexion.cerrarConexion();

            }
            catch (Exception ex)
            {
                MessageBox.Show("No pudo actualizar la informacion de la base de datos, error: " + ex.ToString());
            }
        }

        public void eliminarClientes(TextBox id)
        {
            try
            {

                CConexion objetoConexion = new CConexion();
                string query = "delete from  clientes where id= '" + id.Text + "';";
                MySqlCommand myComand = new MySqlCommand(query, objetoConexion.establecerConexion());
                MySqlDataReader reader = myComand.ExecuteReader();
                MessageBox.Show("Se elimino el registro");
                while (reader.Read())
                {

                }
                //objetoConexion.cerrarConexion();

            }
            catch (Exception ex)
            {
                MessageBox.Show("No pudo eliminar la informacion de la base de datos, error: " + ex.ToString());
            }
        }

    }
}
