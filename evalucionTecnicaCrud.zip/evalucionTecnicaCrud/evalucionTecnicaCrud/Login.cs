﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace evalucionTecnicaCrud
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=localhost;Initial Catalog=LoginDB;Integrated Security=True";
            string query = "SELECT COUNT(1) FROM Users WHERE Username=@Username AND Password=@Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", usernameTextBox.Text);
                command.Parameters.AddWithValue("@Password", passwordTextBox.Text);

       
                int result = (int)command.ExecuteScalar();

                if (result == 1)
                {
                    Form1 frm = new Form1();
                    frm.FormClosed += (s, args) => this.Close();
                    frm.Show();
                    // Aquí puedes abrir otro formulario o hacer lo que necesites después del login.
                }
                else
                {
                    MessageBox.Show("Login Failed");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
