﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace evalucionTecnicaCrud
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Clases.CClientes objetoClientes = new Clases.CClientes();
            objetoClientes.mostrarClientes(dgvTotalClientes);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Clases.CClientes objetoClientes = new Clases.CClientes();
            objetoClientes.guardarClientes(txtnombres, txtidentificaciones, txtcorreos, txtedades, txtcelulares);
            objetoClientes.mostrarClientes(dgvTotalClientes);
        }

        private void dgvTotalClientes_CellMouseClick(object sender, DataGridViewCellEventArgs e)
        {
            Clases.CClientes objetoClientes = new Clases.CClientes();
            objetoClientes.seleccionarClientes(dgvTotalClientes, txtid, txtnombres, txtidentificaciones, txtcorreos, txtedades, txtcelulares);
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            Clases.CClientes objetoClientes = new Clases.CClientes();
            objetoClientes.modificarClientes(txtid, txtnombres, txtidentificaciones, txtcorreos, txtedades, txtcelulares);
            objetoClientes.mostrarClientes(dgvTotalClientes);
        }

        private void dgvTotalClientes_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Clases.CClientes objetoClientes = new Clases.CClientes();
            objetoClientes.eliminarClientes(txtid);
            objetoClientes.mostrarClientes(dgvTotalClientes);
        }

        private void dgvTotalClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void sdfds_Enter(object sender, EventArgs e)
        {

        }

        private void txtcorreos_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
